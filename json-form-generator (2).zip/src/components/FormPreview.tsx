
import React from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';

interface FormPreviewProps {
  schema: any;
}

const FormPreview: React.FC<FormPreviewProps> = ({ schema }) => {
  const { register, handleSubmit, formState: { errors } } = useForm();

  if (!schema || !schema.fields) {
    return <p>No form to display. Enter a valid JSON schema.</p>;
  }

  const onSubmit: SubmitHandler<any> = (data) => {
    console.log('Form Submitted:', data);
    alert('Form submitted successfully!');
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <h2 className="text-xl font-bold">Generated Form</h2>
      {schema.fields.map((field: any) => {
        switch (field.type) {
          case 'text':
          case 'email':
            return (
              <div key={field.id}>
                <label>{field.label}</label>
                <input
                  type={field.type}
                  {...register(field.id, { required: field.required })}
                  placeholder={field.placeholder}
                  className="w-full p-2 border rounded"
                />
                {errors[field.id] && (
                  <p className="text-red-500">{field.label} is required.</p>
                )}
              </div>
            );
          case 'select':
            return (
              <div key={field.id}>
                <label>{field.label}</label>
                <select {...register(field.id, { required: field.required })} className="w-full p-2 border rounded">
                  {field.options.map((option: any) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                {errors[field.id] && (
                  <p className="text-red-500">{field.label} is required.</p>
                )}
              </div>
            );
          case 'radio':
            return (
              <div key={field.id}>
                <label>{field.label}</label>
                {field.options.map((option: any) => (
                  <div key={option.value}>
                    <input
                      type="radio"
                      value={option.value}
                      {...register(field.id, { required: field.required })}
                    />
                    <label>{option.label}</label>
                  </div>
                ))}
                {errors[field.id] && (
                  <p className="text-red-500">{field.label} is required.</p>
                )}
              </div>
            );
          case 'textarea':
            return (
              <div key={field.id}>
                <label>{field.label}</label>
                <textarea
                  {...register(field.id)}
                  placeholder={field.placeholder}
                  className="w-full p-2 border rounded"
                ></textarea>
              </div>
            );
          default:
            return null;
        }
      })}
      <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded">
        Submit
      </button>
    </form>
  );
};

export default FormPreview;
