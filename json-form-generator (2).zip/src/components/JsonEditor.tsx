
import React, { useState } from 'react';

interface JsonEditorProps {
  onChange: (json: any, error: string | null) => void;
}

const JsonEditor: React.FC<JsonEditorProps> = ({ onChange }) => {
  const [input, setInput] = useState<string>('');

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setInput(value);
    try {
      const parsed = JSON.parse(value);
      onChange(parsed, null);
    } catch (err) {
      onChange(null, 'Invalid JSON');
    }
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-2">JSON Editor</h2>
      <textarea
        value={input}
        onChange={handleChange}
        className="w-full h-96 p-2 border rounded"
        placeholder="Enter JSON schema here..."
      ></textarea>
    </div>
  );
};

export default JsonEditor;
