
import React, { useState } from 'react';
import JsonEditor from './components/JsonEditor';
import FormPreview from './components/FormPreview';

const App: React.FC = () => {
  const [jsonSchema, setJsonSchema] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleJsonChange = (json: any, error: string | null) => {
    setJsonSchema(json);
    setError(error);
  };

  return (
    <div className="flex h-screen">
      <div className="w-1/2 border-r p-4">
        <JsonEditor onChange={handleJsonChange} />
      </div>
      <div className="w-1/2 p-4">
        {error ? (
          <p className="text-red-500">{error}</p>
        ) : (
          <FormPreview schema={jsonSchema} />
        )}
      </div>
    </div>
  );
};

export default App;
